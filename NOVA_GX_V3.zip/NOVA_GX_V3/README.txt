NOVA GX V3 - Prototype web local

INSTALLATION
1. Télécharge et décompresse le ZIP.
2. Ouvre le dossier NOVA_GX_V3.
3. Double-clique sur index.html.

NOUVEAUTES
- Interface responsive ordinateur/mobile.
- Memory avec catégories et recherche globale simple.
- Historique de conversations conservé localement.
- Assistant local avec réponses de démonstration.
- Gestion des projets avec progression.
- Gestion des tâches quotidiennes.
- Sauvegarde dans le navigateur via localStorage.

LIMITES
Il ne s'agit pas encore d'une IA générative : l'assistant utilise des réponses prédéfinies.
Les données ne sont pas synchronisées entre appareils et restent dans le navigateur.
Ne stocke pas d'informations sensibles dans ce prototype.
Aucun compte, paiement ou service cloud n'est configuré.

Une future connexion à un fournisseur d'IA ou à une base cloud doit être mise en place
avec une architecture sécurisée et, pour les comptes, clés API et paiements, l'aide
d'un adulte responsable.
